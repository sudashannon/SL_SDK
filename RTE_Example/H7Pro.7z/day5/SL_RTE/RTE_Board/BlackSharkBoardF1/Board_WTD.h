#ifndef __BOARD_WTD_H
#define __BOARD_WTD_H
#include "stm32f10x.h"
#include "RTE_Include.h"
extern void Board_WTD_Init(void) ;
extern void Board_WTD_Feed(void *par);

#endif
