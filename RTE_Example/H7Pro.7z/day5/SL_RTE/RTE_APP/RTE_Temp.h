#ifndef __RTE_TEMP_H
#define __RTE_TEMP_H
#ifdef __cplusplus  
extern "C" {  
#endif  
	#include "RTE_Include.h"
	
	

	
	
#ifdef __cplusplus  
}  
#endif  
#endif