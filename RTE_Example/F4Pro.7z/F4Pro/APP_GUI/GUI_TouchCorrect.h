#ifndef __GUI_TOUCHCORRECT_H
#define __GUI_TOUCHCORRECT_H
#include "RTE_Include.h"
extern void GUI_TouchCorrect_create(void);
#endif
