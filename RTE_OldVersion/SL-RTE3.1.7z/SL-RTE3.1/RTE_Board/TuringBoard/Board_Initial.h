#ifndef __BOARD_INITIAL_H
#define __BOARD_INITIAL_H
#include "Board_Config.h"
#include "stm32h7xx_hal.h"

#endif
