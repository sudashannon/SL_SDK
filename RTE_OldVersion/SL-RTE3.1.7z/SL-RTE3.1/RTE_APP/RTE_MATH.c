/**
  ******************************************************************************
  * @file    RTE_MATH.h
  * @author  Shan Lei ->>lurenjia.tech ->>https://github.com/sudashannon
  * @brief   RTE�Դ���һЩ��ѧ���㡣
  * @version V1.0 2018/11/02 ��һ��
	* @History V1.0 ����
  ******************************************************************************
  */
#include "RTE_MATH.h"
