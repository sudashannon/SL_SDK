#include "RTE_Include.h"
/*****************************************************************************
*** Author: Shannon
*** Version: 2.3 2018.10.2
*** History: 1.0 �������޸���tivaware
             2.0 ΪRTE�����������䣬����ģ������
						 2.1 ����̬��Ϸ�ʽ����
						 2.2 ����RTE_Vec����ͳһ����
						 2.3 ���̻߳���������ALONE���ƣ�ȷ��ĳЩ�ؼ�timer�����ڶ������߳�������
*****************************************************************************/
#if RTE_USE_ROUNDROBIN == 1
#if RTE_USE_OS == 1
#include "RTE_Components.h"
#include CMSIS_device_header
#endif
/*************************************************
*** ����RoundRobin�Ľṹ���������̬����
*************************************************/
static RTE_RoundRobin_t RoundRobinHandle;
/*************************************************
*** Args:   Timer ��������ʱ��
*** Function: SoftTimer��ʱ����
*************************************************/
static void RTE_RoundRobin_CheckTimer(uint8_t Timer)
{
	// Loop through each task in the task table.
	for(uint8_t i = 0; i < RoundRobinHandle.SoftTimerTable.length; i++)
	{
		/* Check if count is zero */
#if RTE_USE_OS == 1
		if (RoundRobinHandle.SoftTimerTable.data[Timer].CNT == 0 && RoundRobinHandle.SoftTimerTable.data[Timer].ALONE == 0) {
#else
		if (RoundRobinHandle.SoftTimerTable.data[Timer].CNT == 0 ) {
#endif
			/* Call user callback function */
			RoundRobinHandle.SoftTimerTable.data[Timer].Callback(RoundRobinHandle.SoftTimerTable.data[Timer].UserParameters);
			/* Set new counter value */
			RoundRobinHandle.SoftTimerTable.data[Timer].CNT = RoundRobinHandle.SoftTimerTable.data[Timer].ARR;
			/* Remove timer if auto reload feature is not used */
			if (!RoundRobinHandle.SoftTimerTable.data[Timer].AREN) {
				RoundRobinHandle.SoftTimerTable.data[Timer].CNTEN = 0;
			}
		}
	}
}
/*************************************************
*** Args:   Null
*** Function: RoundRobinʱ������
*************************************************/
void RTE_RoundRobin_TickHandler(void)
{
  RoundRobinHandle.RoundRobinRunTick++;
	// Loop through each task in the task table.
	for(uint8_t i = 0; i < RoundRobinHandle.SoftTimerTable.length; i++)
	{
    if(RoundRobinHandle.SoftTimerTable.data[i].CNTEN)
		{
			/* Decrease counter if needed */
			if (RoundRobinHandle.SoftTimerTable.data[i].CNT)
				RoundRobinHandle.SoftTimerTable.data[i].CNT--;
#if RTE_USE_OS == 1
			RTE_RoundRobin_CheckTimer(i);
#endif
		}
	}
}
/*************************************************
*** Args:   Null
*** Function: RoundRobin���к��� �ڷǲ���ϵͳ�����µ���
*************************************************/
#if RTE_USE_OS == 0
void RTE_RoundRobin_Run(void)
{
	// Loop through each task in the task table.
	for(uint8_t i = 0; i < RoundRobinHandle.SoftTimerTable.length; i++)
	{
		RTE_RoundRobin_CheckTimer(i);
	}
}
#endif
/*************************************************
*** Args:   
					*Name �����Ӷ�ʱ������
					ReloadValue ��װ��ֵ
          ReloadEnable ��װ��ʹ��
          ReloadEnable ��ʱ������ʹ��
          *TimerCallback ��ʱ���ص�����
          *UserParameters �ص������������
*** Function: Ϊ��ǰRoundRobin��������һ������ʱ��
*************************************************/
RTE_RoundRobin_Err_e RTE_RoundRobin_CreateTimer(const char *Name,
	uint32_t ReloadValue, 
	uint8_t ReloadEnable, 
	uint8_t RunEnable, 
#if RTE_USE_OS == 1
	uint8_t AloneEnable,
#endif
	void (*TimerCallback)(void *), 
	void* UserParameters)
{
	if(RoundRobinHandle.SoftTimerTable.length >= HI_ROUNDROBIN_MAX_NUM)
		return RR_NOSPACEFORNEW;
	for(uint8_t i = 0;i<RoundRobinHandle.SoftTimerTable.length;i++)
	{
		if(!strcmp(Name,RoundRobinHandle.SoftTimerTable.data[i].TimerName))
			return RR_ALREADYEXIST;
	}
	RTE_SoftTimer_t v;
	v.TimerName = Name;
	v.AREN = ReloadEnable;
	v.CNTEN = RunEnable;
	v.ARR = ReloadValue;
	v.CNT = ReloadValue;
#if RTE_USE_OS == 1
	v.ALONE = AloneEnable;
#endif
	v.Callback = TimerCallback;
	v.UserParameters = UserParameters;
	vec_push(&RoundRobinHandle.SoftTimerTable, v);
	return RR_NOERR;
}
/*************************************************
*** Args:   
					*Name ��ɾ����ʱ������
*** Function: Ϊ��ǰRoundRobin����ɾ��һ������ʱ��
*************************************************/
RTE_RoundRobin_Err_e RTE_RoundRobin_RemoveTimer(const char *Name)
{
	int8_t idx = -1;
	for(uint8_t i = 0;i<RoundRobinHandle.SoftTimerTable.length;i++)
	{
		if(!ustrcmp(Name,RoundRobinHandle.SoftTimerTable.data[i].TimerName))
		{
			idx = i;
			break;
		}
	}
	if(idx!=-1)
	{
		vec_splice(&RoundRobinHandle.SoftTimerTable, idx, 1);
		return RR_NOERR;
	}
	return RR_NOSUCHTIMER;
}
/*************************************************
*** Args:   
					*Name ����ͣ��ʱ������
*** Function: ��ͣ��ǰRoundRobin�����е�һ������ʱ��
*************************************************/
RTE_RoundRobin_Err_e RTE_RoundRobin_PauseTimer(const char *Name) 
{
	int8_t idx = -1;
	for(uint8_t i = 0;i<RoundRobinHandle.SoftTimerTable.length;i++)
	{
		if(!ustrcmp(Name,RoundRobinHandle.SoftTimerTable.data[i].TimerName))
		{
			idx = i;
			break;
		}
	}
	if(idx!=-1)
	{
		RoundRobinHandle.SoftTimerTable.data[idx].CNTEN = 0;
		return RR_NOERR;
	}
	return RR_NOSUCHTIMER;
}
/*************************************************
*** Args:   
					*Name ����ͣ��ʱ������
*** Function: �ָ���ǰRoundRobin�����е�һ������ʱ��
*************************************************/
RTE_RoundRobin_Err_e RTE_RoundRobin_ResumeTimer(const char *Name) 
{
	int8_t idx = -1;
	for(uint8_t i = 0;i<RoundRobinHandle.SoftTimerTable.length;i++)
	{
		if(!ustrcmp(Name,RoundRobinHandle.SoftTimerTable.data[i].TimerName))
		{
			idx = i;
			break;
		}
	}
	if(idx!=-1)
	{
		RoundRobinHandle.SoftTimerTable.data[idx].CNTEN = 1;
		return RR_NOERR;
	}
	return RR_NOSUCHTIMER;
}
/*************************************************
*** Args:   
					Null
*** Function: ��ȡ��ǰRoundRobin������Ϣ
*************************************************/
void RTE_RoundRobin_Demon(void)
{
	RTE_Printf("[RR]    ��ǰ��ת����TIMERʹ����Ŀ��%d �����Ŀ��%d VEC������%d\r\n",
	RoundRobinHandle.SoftTimerTable.length ,HI_ROUNDROBIN_MAX_NUM,RoundRobinHandle.SoftTimerTable.capacity);
	for(uint8_t i = 0;i<RoundRobinHandle.SoftTimerTable.length;i++)
	{
		RTE_Printf("[RR]    TIMER:%16s----�Զ����أ�%x ����ֵ��%6d ��ǰֵ��%6d ���У�%x �ֶ�������%x\r\n",
			RoundRobinHandle.SoftTimerTable.data[i].TimerName,RoundRobinHandle.SoftTimerTable.data[i].AREN,RoundRobinHandle.SoftTimerTable.data[i].ARR
			,RoundRobinHandle.SoftTimerTable.data[i].CNT,RoundRobinHandle.SoftTimerTable.data[i].CNTEN,RoundRobinHandle.SoftTimerTable.data[i].ALONE);
	}
}
/*************************************************
*** Args:   
					Null
*** Function: ��ȡ��ǰRoundRobin��������ʱ��
*************************************************/
uint32_t RTE_RoundRobin_GetTick(void) 
{
	/* Return current time in milliseconds */
#if RTE_USE_OS == 1
	if (osKernelGetState () == osKernelRunning) 
	{
    return RoundRobinHandle.RoundRobinRunTick;
  }
	#endif
	else
	{
		static uint32_t ticks = 0U;
					 uint32_t i;
		/* If Kernel is not running wait approximately 1 ms then increment 
			 and return auxiliary tick counter value */
		for (i = (SystemCoreClock >> 14U); i > 0U; i--) {
			__NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();
			__NOP(); __NOP(); __NOP(); __NOP(); __NOP(); __NOP();
		}
		return ++ticks;
	}
#else
	return RoundRobinHandle.RoundRobinRunTick;
#endif 
}
/*************************************************
*** Args:   NULL
*** Function: RoundRobin��ʼ��
*************************************************/
void RTE_RoundRobin_Init(void)
{
	vec_init(&RoundRobinHandle.SoftTimerTable);
	RoundRobinHandle.RoundRobinRunTick = 0;
	/* Enable TRC */
	CoreDebug->DEMCR &= ~0x01000000;
	CoreDebug->DEMCR |=  0x01000000;
	/* Enable counter */
	DWT->CTRL &= ~0x00000001;
	DWT->CTRL |=  0x00000001;
	/* Reset counter */
	DWT->CYCCNT = 0;	
	/* 2 dummys */
	__ASM volatile ("NOP");
	__ASM volatile ("NOP");
}
/*************************************************
*** Args:   
					*Name ����λ��ʱ������
*** Function: ��λ��ǰRoundRobin�����е�һ������ʱ��
*************************************************/
RTE_RoundRobin_Err_e RTE_RoundRobin_ResetTimer(const char *Name) 
{
	int8_t idx = -1;
	for(uint8_t i = 0;i<RoundRobinHandle.SoftTimerTable.length;i++)
	{
		if(!ustrcmp(Name,RoundRobinHandle.SoftTimerTable.data[i].TimerName))
		{
			idx = i;
			break;
		}
	}
	if(idx!=-1)
	{
		RoundRobinHandle.SoftTimerTable.data[idx].CNT = RoundRobinHandle.SoftTimerTable.data[idx].ARR;
		RoundRobinHandle.SoftTimerTable.data[idx].CNTEN = 1;
	}
	else
		return RR_NOSUCHTIMER;
	return RR_NOERR;
}
/*************************************************
*** Args:   
					prev_tick a previous time stamp (return value of systick_get() )
*** Function: ��ȡ����tick֮��ʱ���
*************************************************/
uint32_t RTE_RoundRobin_TickElaps(uint32_t prev_tick)
{
	uint32_t act_time = RTE_RoundRobin_GetTick();
	/*If there is no overflow in sys_time simple subtract*/
	if(act_time >= prev_tick) {
		prev_tick = act_time - prev_tick;
	} else {
		prev_tick = UINT32_MAX - prev_tick + 1;
		prev_tick += act_time;
	}
	return prev_tick;
}
/*************************************************
*** Args:   
					*Name ����λ��ʱ������
*** Function: ��λ��ǰRoundRobin�����е�һ������ʱ��
*************************************************/
RTE_RoundRobin_Err_e RTE_RoundRobin_ReadyTimer(const char *Name) 
{
	int8_t idx = -1;
	for(uint8_t i = 0;i<RoundRobinHandle.SoftTimerTable.length;i++)
	{
		if(!ustrcmp(Name,RoundRobinHandle.SoftTimerTable.data[i].TimerName))
		{
			idx = i;
			break;
		}
	}
	if(idx!=-1)
	{
		RoundRobinHandle.SoftTimerTable.data[idx].CNT = 0;
		RoundRobinHandle.SoftTimerTable.data[idx].CNTEN = 1;
	}
	else
		return RR_NOSUCHTIMER;
	return RR_NOERR;
}
/*************************************************
*** Args:   Delay
					Null
*** Function: ��ʱһ�κ���
*************************************************/
void RTE_RoundRobin_DelayMS(uint32_t Delay) {
	/* Delay for amount of milliseconds */
	/* Check if we are called from ISR */
	if (__get_IPSR() == 0) {
		/* Called from thread mode */
		uint32_t tickstart = RTE_RoundRobin_GetTick();
		/* Count interrupts */
		while ((RTE_RoundRobin_GetTick() - tickstart) < Delay) {
#if RTE_USE_LOWPOWER == 1
			/* Go sleep, wait systick interrupt */
			__WFI();
#endif
		}
	} else {
		/* Called from interrupt mode */
		while (Delay) {
			/* Check if timer reached zero after we last checked COUNTFLAG bit */
			if (SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk) {
				Delay--;
			}
		}
	}
}
/*************************************************
*** Args:   Timer ��������ʱ��
*** Function: SoftTimer��ʱ����
*************************************************/
#if RTE_USE_OS == 1
RTE_RoundRobin_Err_e RTE_RoundRobin_RunAloneTimer(const char* Name)
{
	int8_t idx = -1;
	for(uint8_t i = 0;i<RoundRobinHandle.SoftTimerTable.length;i++)
	{
		if(!ustrcmp(Name,RoundRobinHandle.SoftTimerTable.data[i].TimerName))
		{
			idx = i;
			break;
		}
	}
	if(idx!=-1)
	{
		/* Check if count is zero */
		if (RoundRobinHandle.SoftTimerTable.data[idx].CNT == 0 && RoundRobinHandle.SoftTimerTable.data[idx].ALONE == 1) {
			/* Call user callback function */
			RoundRobinHandle.SoftTimerTable.data[idx].Callback(RoundRobinHandle.SoftTimerTable.data[idx].UserParameters);
			/* Set new counter value */
			RoundRobinHandle.SoftTimerTable.data[idx].CNT = RoundRobinHandle.SoftTimerTable.data[idx].ARR;
			/* Remove timer if auto reload feature is not used */
			if (!RoundRobinHandle.SoftTimerTable.data[idx].AREN) {
				RoundRobinHandle.SoftTimerTable.data[idx].CNTEN = 0;
			}
		}
	}
	else
		return RR_NOSUCHTIMER;
	return RR_NOERR;
}
#endif
/*************************************************
*** Args:   micros ΢��
*** Function: ��ʱ΢�룬��Ӱ��ϵͳ����
*************************************************/
__inline void RTE_RoundRobin_DelayUS(volatile uint32_t micros) {
	uint32_t start = DWT->CYCCNT;
	/* Go to number of cycles for system */
	micros *= (SystemCoreClock / 1000000);
	/* Delay till end */
	while ((DWT->CYCCNT - start) < micros);
}
