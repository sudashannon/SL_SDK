#include "RTE_Include.h"
/*****************************************************************************
*** Author: Shannon
*** Version: 2.2 2018.10.02
*** History: 1.0 ����
             2.0 ΪRTE������������
						 2.1 �����˼���������
						 2.2 Ϊ���ӵ�GUI�ں�������
*****************************************************************************/
/*************************************************
*** Args:   *file  ����ʧ�ܵ��ļ�;
            line ����ʧ�ܵ���;
*** Function: ���Թ���
*************************************************/
void RTE_Assert(char *file, uint32_t line)
{ 
	RTE_Printf("[ASSERT]    Wrong parameters value: file %s on line %d\r\n", file, line);
	while (1)
	{
		
	}
}
/*************************************************
*** RTE���������ڴ棬��̬���䣬32λ����
*************************************************/
#if RTE_USE_BGET == 1
#define ALIGN_32BYTES(buf) buf __attribute__ ((aligned (32)))
ALIGN_32BYTES (uint8_t RTE_RAM[RTE_MEM_SIZE * 1024] __attribute__((at(0x10000000)))) = {0};
#endif
/*************************************************
*** RTE_Shell�Ļص�����
*************************************************/
#if HI_USE_SHELL == 1
static void Shell_TimerCallBack(void *Params)
{
	RTE_Shell_Poll();
}
#endif
/*************************************************
*** Args:   NULL
*** Function: RTE��ʼ��
*************************************************/
void RTE_Init(void)
{
#if RTE_USE_BGET == 1
	RTE_BPool(MEM_RTE,RTE_RAM,RTE_MEM_SIZE*1024);
#endif
#if RTE_USE_ROUNDROBIN == 1
	RTE_RoundRobin_Init();
	#if RTE_USE_HUMMANINTERFACE == 1
		#if HI_USE_SHELL == 1
			RTE_Shell_Init();
			RTE_RoundRobin_CreateTimer("ShellTimer",10,1,1,0,Shell_TimerCallBack,(void *)0);
		#endif
	#endif
#endif
#if RTE_USE_STDIO != 1
	#if RTE_USE_OS == 1
	MutexIDStdio = osMutexNew(NULL);
	#endif
#endif
#if RTE_USE_FS
    fs_init();
#endif
#if RTE_USE_UFS
    ufs_init();
#endif
}
