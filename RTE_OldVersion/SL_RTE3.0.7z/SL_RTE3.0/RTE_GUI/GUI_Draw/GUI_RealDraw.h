/**
 * @file draw_rbasic..h
 * 
 */

#ifndef GUI_DRAW_RBASIC_H
#define GUI_DRAW_RBASIC_H

#ifdef __cplusplus
extern "C" {
#endif

/*********************
 *      INCLUDES
 *********************/
#include "RTE_Include.h"
#if GUI_USE_REAL_DRAW != 0

/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 * GLOBAL PROTOTYPES
 **********************/

void rpx(coord_t x, coord_t y, const area_t * mask_p, color_t color, opa_t opa);

/**
 * Fill an area on the display
 * @param cords_p coordinates of the area to fill
 * @param mask_p fill only o this mask
 * @param color fill color
 * @param opa opacity (ignored, only for compatibility with vfill)
 */
void rfill(const area_t * cords_p, const area_t * mask_p,
                color_t color, opa_t opa);

/**
 * Draw a letter to the display
 * @param pos_p left-top coordinate of the latter
 * @param mask_p the letter will be drawn only on this area
 * @param font_p pointer to font
 * @param letter a letter to draw
 * @param color color of letter
 * @param opa opacity of letter (ignored, only for compatibility with vletter)
 */
void rletter(const point_t * pos_p, const area_t * mask_p,
                const font_t * font_p, uint32_t letter,
                color_t color, opa_t opa);

/**
 * When the letter is ant-aliased it needs to know the background color
 * @param bg_color the background color of the currently drawn letter
 */
void rletter_set_background(color_t color);


/**
 * Draw a color map to the display (image)
 * @param cords_p coordinates the color map
 * @param mask_p the map will drawn only on this area
 * @param map_p pointer to a color_t array
 * @param opa opacity of the map (ignored, only for compatibility with 'vmap')
 * @param chroma_keyed true: enable transparency of GUI_IMG_GUI_COLOR_TRANSP color pixels
 * @param alpha_byte true: extra alpha byte is inserted for every pixel (not supported, only l'v_vmap' can draw it)
 * @param recolor mix the pixels with this color
 * @param recolor_opa the intense of recoloring
 */
void rmap(const area_t * cords_p, const area_t * mask_p,
            const uint8_t * map_p, opa_t opa, bool chroma_key, bool alpha_byte,
            color_t recolor, opa_t recolor_opa);
/**********************
 *      MACROS
 **********************/

#endif  /*GUI_USE_REAL_DRAW*/

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif  /*GUI_DRAW_RBASIC_H*/
