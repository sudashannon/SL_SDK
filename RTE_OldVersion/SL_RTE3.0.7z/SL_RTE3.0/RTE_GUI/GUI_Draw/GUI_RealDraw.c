#include "RTE_Include.h"
#if GUI_REAL_DRAW == 1
/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/

/**********************
 *  STATIC VARIABLES
 **********************/
static color_t letter_bg_color;

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

/**
 * Put a pixel to the display
 * @param x x coordinate of the pixel
 * @param y y coordinate of the pixel
 * @param mask_p the pixel will be drawn on this area
 * @param color color of the pixel
 * @param opa opacity (ignored, only for compatibility with vpx)
 */
void rpx(coord_t x, coord_t y, const area_t * mask_p, color_t color, opa_t opa)
{
    (void)opa;      /*Opa is used only for compatibility with vpx*/

    area_t area;
    area.x1 = x;
    area.y1 = y;
    area.x2 = x;
    area.y2 = y;

    rfill(&area, mask_p, color, GUI_OPA_COVER);
}

/**
 * Fill an area on the display
 * @param cords_p coordinates of the area to fill
 * @param mask_p fill only o this mask
 * @param color fill color
 * @param opa opacity (ignored, only for compatibility with vfill)
 */
void rfill(const area_t * cords_p, const area_t * mask_p, 
              color_t color, opa_t opa)
{   

    (void)opa;      /*Opa is used only for compatibility with vfill*/

    area_t masked_area;
    bool union_ok = true;
    
    if(mask_p != NULL) {
        union_ok = area_union(&masked_area, cords_p, mask_p);
    } else {
        area_t scr_area;
        area_set(&scr_area, 0, 0, GUI_HOR_RES - 1, GUI_VER_RES - 1);
        union_ok = area_union(&masked_area, cords_p, &scr_area);
    }
    
    if(union_ok != false){
    	disp_fill(masked_area.x1, masked_area.y1, masked_area.x2, masked_area.y2, color);
    }
}

/**
 * Draw a letter to the display
 * @param pos_p left-top coordinate of the latter
 * @param mask_p the letter will be drawn only on this area
 * @param font_p pointer to font 
 * @param letter a letter to draw
 * @param color color of letter
 * @param opa opacity of letter (ignored, only for compatibility with vletter)
 */
void rletter(const point_t * pos_p, const area_t * mask_p,
                     const font_t * font_p, uint32_t letter,
                     color_t color, opa_t opa)
{
    (void)opa;      /*Opa is used only for compatibility with vletter*/

    static uint8_t bpp1_opa_table[2] =  {0, 255};                   /*Opacity mapping with bpp = 1 (Just for compatibility)*/
    static uint8_t bpp2_opa_table[4] =  {0, 85, 170, 255};          /*Opacity mapping with bpp = 2*/
    static uint8_t bpp4_opa_table[16] = {0,   17,  34,  51,         /*Opacity mapping with bpp = 4*/
                                        68,  85,  102, 119,
                                        136, 153, 170, 187,
                                        204, 221, 238, 255};

    if(font_p == NULL) return;

    uint8_t letter_w = font_get_width(font_p, letter);
    uint8_t letter_h = font_get_height(font_p);
    uint8_t bpp = font_get_bpp(font_p, letter);  /*Bit per pixel (1,2, 4 or 8)*/
    uint8_t *bpp_opa_table;
    uint8_t mask_init;
    uint8_t mask;

    switch(bpp) {
        case 1: bpp_opa_table = bpp1_opa_table;  mask_init = 0x80; break;
        case 2: bpp_opa_table = bpp2_opa_table;  mask_init = 0xC0; break;
        case 4: bpp_opa_table = bpp4_opa_table;  mask_init = 0xF0; break;
        case 8: bpp_opa_table = NULL;  mask_init = 0xFF; break;             /*No opa table, pixel value will be used directly*/
        default: return;        /*Invalid bpp. Can't render the letter*/
    }

    const uint8_t * map_p = font_get_bitmap(font_p, letter);

    if(map_p == NULL) return;

    /*If the letter is completely out of mask don't draw it */
    if(pos_p->x + letter_w < mask_p->x1 || pos_p->x > mask_p->x2 ||
       pos_p->y + letter_h < mask_p->y1 || pos_p->y > mask_p->y2) return;

    coord_t col, row;
    uint8_t col_bit;
    uint8_t col_byte_cnt;
    uint8_t width_byte_scr = letter_w >> 3;      /*Width in bytes (on the screen finally) (e.g. w = 11 -> 2 bytes wide)*/
    if(letter_w & 0x7) width_byte_scr++;
    uint8_t width_byte_bpp = (letter_w * bpp) >> 3;    /*Letter width in byte. Real width in the font*/
    if((letter_w * bpp) & 0x7) width_byte_bpp++;

    /* Calculate the col/row start/end on the map*/
    coord_t col_start = pos_p->x >= mask_p->x1 ? 0 : mask_p->x1 - pos_p->x;
    coord_t col_end = pos_p->x + letter_w <= mask_p->x2 ? letter_w : mask_p->x2 - pos_p->x + 1;
    coord_t row_start = pos_p->y >= mask_p->y1 ? 0 : mask_p->y1 - pos_p->y;
    coord_t row_end  = pos_p->y + letter_h <= mask_p->y2 ? letter_h : mask_p->y2 - pos_p->y + 1;

    /*Move on the map too*/
    map_p += (row_start * width_byte_bpp) + ((col_start * bpp) >> 3);

    uint8_t letter_px;
    for(row = row_start; row < row_end; row ++) {
        col_byte_cnt = 0;
        col_bit = (col_start * bpp) % 8;
        mask = mask_init >> col_bit;
        for(col = col_start; col < col_end; col ++) {
            letter_px = (*map_p & mask) >> (8 - col_bit - bpp);
            if(letter_px != 0) {
                rpx(pos_p->x + col, pos_p->y + row, mask_p, color_mix(color, letter_bg_color, bpp == 8 ? letter_px : bpp_opa_table[letter_px]), GUI_OPA_COVER);
            }

            if(col_bit < 8 - bpp) {
                col_bit += bpp;
                mask = mask >> bpp;
            }
            else {
                col_bit = 0;
                col_byte_cnt ++;
                mask = mask_init;
                map_p ++;
            }
        }

        map_p += (width_byte_bpp) - col_byte_cnt;
    }
}

/**
 * When the letter is ant-aliased it needs to know the background color
 * @param bg_color the background color of the currently drawn letter
 */
void rletter_set_background(color_t color)
{
    letter_bg_color = color;
}

/**
 * Draw a color map to the display (image)
 * @param cords_p coordinates the color map
 * @param mask_p the map will drawn only on this area
 * @param map_p pointer to a color_t array
 * @param opa opacity of the map (ignored, only for compatibility with 'vmap')
 * @param chroma_keyed true: enable transparency of GUI_IMG_GUI_COLOR_TRANSP color pixels
 * @param alpha_byte true: extra alpha byte is inserted for every pixel (not supported, only l'v_vmap' can draw it)
 * @param recolor mix the pixels with this color
 * @param recolor_opa the intense of recoloring
 */
void rmap(const area_t * cords_p, const area_t * mask_p,
            const uint8_t * map_p, opa_t opa, bool chroma_key, bool alpha_byte,
            color_t recolor, opa_t recolor_opa)
{
    if(alpha_byte) return;      /*Pixel level opacity i not supported in real map drawing*/

    (void)opa;              /*opa is used only for compatibility with vmap*/
    area_t masked_a;
    bool union_ok;

    union_ok = area_union(&masked_a, cords_p, mask_p);

    /*If there are common part of the mask and map then draw the map*/
    if(union_ok == false) return;

    /*Go to the first pixel*/
    coord_t map_width = area_get_width(cords_p);
    map_p += (masked_a.y1 - cords_p->y1) * map_width * sizeof(color_t);
    map_p += (masked_a.x1 - cords_p->x1) * sizeof(color_t);

    coord_t row;
    if(recolor_opa == GUI_OPA_TRANSP && chroma_key == false) {
        coord_t mask_w = area_get_width(&masked_a) - 1;
        for(row = masked_a.y1; row <= masked_a.y2; row++) {
            disp_map(masked_a.x1, row, masked_a.x1 + mask_w, row, (color_t*)map_p);
            map_p += map_width * sizeof(color_t);               /*Next row on the map*/
        }
    } else {
        color_t chroma_key_color = GUI_COLOR_TRANSP;
        coord_t col;
        for(row = masked_a.y1; row <= masked_a.y2; row++) {
            for(col = masked_a.x1; col <= masked_a.x2; col++) {
                color_t * px_color = (color_t *) &map_p[(uint32_t)(col - masked_a.x1) * sizeof(color_t)];

                if(chroma_key && chroma_key_color.full == px_color->full) continue;

                if(recolor_opa != GUI_OPA_TRANSP) {
                    color_t recolored_px = color_mix(recolor, *px_color, recolor_opa);

                    rpx(col, row, mask_p, recolored_px, GUI_OPA_COVER);
                } else {
                    rpx(col, row, mask_p, *px_color, GUI_OPA_COVER);
                }

            }
            map_p += map_width * sizeof(color_t);               /*Next row on the map*/
        }
    }
}

/**********************
 *   STATIC FUNCTIONS
 **********************/
#endif
