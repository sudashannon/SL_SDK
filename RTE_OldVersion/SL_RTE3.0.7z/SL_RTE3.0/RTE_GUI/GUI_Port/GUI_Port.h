#ifndef __GUI_PORT_H
#define __GUI_PORT_H
extern void GUI_Port_Init(void);
#endif
