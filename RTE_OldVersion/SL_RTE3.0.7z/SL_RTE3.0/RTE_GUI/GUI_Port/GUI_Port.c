#include "Board_LCDFSMC.h"
#include "Board_Touch.h"
/**********************
 *   STATIC FUNCTIONS
 **********************/
#define TFT_HOR_RES LCD_Handle.Width
#define TFT_VER_RES LCD_Handle.Height
/**
 * Fill a rectangular area with a color
 * @param x1 left coordinate of the rectangle
 * @param x2 right coordinate of the rectangle
 * @param y1 top coordinate of the rectangle
 * @param y2 bottom coordinate of the rectangle
 * @param color fill color
 */
void tft_fill(int32_t x1, int32_t y1, int32_t x2, int32_t y2, color_t color)
{
    /*Return if the area is out the screen*/
    if(x2 < 0) return;

    if(y2 < 0) return;

    if(x1 > TFT_HOR_RES - 1) return;

    if(y1 > TFT_VER_RES - 1) return;

    /*Truncate the area to the screen*/
    int32_t act_x1 = x1 < 0 ? 0 : x1;
    int32_t act_y1 = y1 < 0 ? 0 : y1;
    int32_t act_x2 = x2 > TFT_HOR_RES - 1 ? TFT_HOR_RES - 1 : x2;
    int32_t act_y2 = y2 > TFT_VER_RES - 1 ? TFT_VER_RES - 1 : y2;

    LCD_Fill_onecolor(act_x1, act_y1, act_x2 - act_x1 + 1, act_y2 - act_y1 + 1, ((color.full) | 0xFF000000));
}

/**
 * Put a color map to a rectangular area
 * @param x1 left coordinate of the rectangle
 * @param x2 right coordinate of the rectangle
 * @param y1 top coordinate of the rectangle
 * @param y2 bottom coordinate of the rectangle
 * @param color_p pointer to an array of colors
 */
void tft_map(int32_t x1, int32_t y1, int32_t x2, int32_t y2, const color_t * color_p)
{
    /*Return if the area is out the screen*/
    if(x2 < 0) return;

    if(y2 < 0) return;

    if(x1 > TFT_HOR_RES - 1) return;

    if(y1 > TFT_VER_RES - 1) return;

    /*Truncate the area to the screen*/
    int32_t act_x1 = x1 < 0 ? 0 : x1;
    int32_t act_y1 = y1 < 0 ? 0 : y1;
    int32_t act_x2 = x2 > TFT_HOR_RES - 1 ? TFT_HOR_RES - 1 : x2;
    int32_t act_y2 = y2 > TFT_VER_RES - 1 ? TFT_VER_RES - 1 : y2;


    uint32_t x;
    uint32_t y;

    /*Put the map to the remaining area*/
    for(y = act_y1; y <= act_y2; y++)
    {
        for(x = act_x1; x <= act_x2; x++)
        {
            /*Your specific function comes here!*/
            /*my_put_pixel(x, y, color_p->full);*/
            LCD_Color_DrawPoint(x, y,  ((color_p->full) | 0xFF000000));
            color_p++;
        }

        color_p += x2 - act_x2;	/*Skip the parts out of the screen*/
    }
    flush_ready();
}

/**
 * Flush a color buffer
 * @param x1 left coordinate of the rectangle
 * @param x2 right coordinate of the rectangle
 * @param y1 top coordinate of the rectangle
 * @param y2 bottom coordinate of the rectangle
 * @param color_p pointer to an array of colors
 */
static void tft_flush(int32_t x1, int32_t y1, int32_t x2, int32_t y2, const color_t * color_p)
{
    /*Return if the area is out the screen*/
    if(x2 < 0) return;

    if(y2 < 0) return;

    if(x1 > TFT_HOR_RES - 1) return;

    if(y1 > TFT_VER_RES - 1) return;

    /*Truncate the area to the screen*/
    int32_t act_x1 = x1 < 0 ? 0 : x1;
    int32_t act_y1 = y1 < 0 ? 0 : y1;
    int32_t act_x2 = x2 > TFT_HOR_RES - 1 ? TFT_HOR_RES - 1 : x2;
    int32_t act_y2 = y2 > TFT_VER_RES - 1 ? TFT_VER_RES - 1 : y2;

    uint32_t x;
    uint32_t y;

    /*Put the map to the remaining area*/
    for(y = act_y1; y <= act_y2; y++)
    {
        for(x = act_x1; x <= act_x2; x++)
        {
            /*Your specific function comes here!*/
            /*my_put_pixel(x, y, color_p->full);*/
            LCD_Color_DrawPoint(x, y,  ((color_p->full) | 0xFF000000));
            color_p++;
        }

        color_p += x2 - act_x2;	/*Skip the parts out of the screen*/
    }
    flush_ready();
}

void tft_init(void)
{
	disp_drv_t disp_drv;
	disp_drv_init(&disp_drv);

	disp_drv.disp_fill = tft_fill;
	disp_drv.disp_map = tft_map;
	disp_drv.disp_flush = tft_flush;
	disp_drv_register(&disp_drv);
}
/**********************
 *   STATIC FUNCTIONS
 **********************/
/**
 * Read an input device
 * @param indev_id id of the input device to read
 * @param x put the x coordinate here
 * @param y put the y coordinate here
 * @return true: the device is pressed, false: released
 */
extern u16 Xdown; 		 
extern u16 Ydown;	   //�����������¾ͷ��صĵ�����ֵ
static bool touchpad_read(indev_data_t *data)
{
	static int16_t last_x = 0;
	static int16_t last_y = 0;
	TP_Scan(0);
	if(Xdown !=0xffff && Ydown != 0xffff) {
		data->point.x = Xdown;
		data->point.y = Ydown;
		last_x = data->point.x;
		last_y = data->point.y;
		data->state = GUI_INDEV_STATE_PR;
	} else {
		data->point.x = last_x;
		data->point.y = last_y;
		data->state = GUI_INDEV_STATE_REL;
	}

	return false;
}

/**
 * Initialize your input devices here
 */
void touchpad_init(void)
{
	Touch_Init();				//��������ʼ��
  indev_drv_t indev_drv;
  indev_drv_init(&indev_drv);
  indev_drv.read = touchpad_read;
  indev_drv.type = GUI_INDEV_TYPE_POINTER;
  indev_drv_register(&indev_drv);
}

void GUI_Port_Init(void)
{
	tft_init();
	touchpad_init();
}
