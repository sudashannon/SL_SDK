#ifndef __BSP_WATCHDOG_H
#define __BSP_WATCHDOG_H
#include "tm4c1294ncpdt.h"
#include "RTE_Include.h"
#include "watchdog.h"
#include "sysctl.h"
#include "interrupt.h"
#include "hw_ints.h"
extern void BSP_WatchDog_Init(void);
#endif
