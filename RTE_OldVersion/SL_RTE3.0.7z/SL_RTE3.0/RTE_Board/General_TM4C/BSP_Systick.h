#ifndef __BSP_SYSTICK_H
#define __BSP_SYSTICK_H
#include "tm4c1294ncpdt.h"
#include "RTE_Include.h"
#include "systick.h"
extern void BSP_Systick_Init(void);
#endif
